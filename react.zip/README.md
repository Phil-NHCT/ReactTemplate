# ReactTemplate
Basic React Template with bootstrap, header footer, menu and AD connection.
